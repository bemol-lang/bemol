const fs = require('fs');
const path = require('path');
const vsctm = require('vscode-textmate');
const oniguruma = require('vscode-oniguruma');
const wasm = fs.readFileSync(path.join(__dirname, '../node_modules/vscode-oniguruma/release/onig.wasm')).buffer;
const onigLib = oniguruma.loadWASM(wasm).then(() => ({
  createOnigScanner: (s) => new oniguruma.OnigScanner(s),
  createOnigString: (s) => new oniguruma.OnigString(s),
}));
const registry = new vsctm.Registry({
  onigLib,
  loadGrammar: async () => vsctm.parseRawGrammar(fs.readFileSync(path.join(__dirname, '../syntaxes/bemol.tmLanguage.json'), 'utf8'), 'x.json'),
});
registry.loadGrammar('source.bemol').then((g) => {
  const src = fs.readFileSync(process.argv[2], 'utf8').split('\n');
  let stack = vsctm.INITIAL;
  const counts = {};
  for (const line of src.slice(0, Number(process.argv[3] || 9999))) {
    const r = g.tokenizeLine(line, stack);
    stack = r.ruleStack;
    const parts = [];
    for (const t of r.tokens) {
      const txt = line.substring(t.startIndex, t.endIndex);
      const sc = t.scopes[t.scopes.length - 1];
      if (sc !== 'source.bemol' && txt.trim()) parts.push(`${txt.trim()}⟨${sc.replace(/\.bemol$/, '')}⟩`);
    }
    if (process.argv[4]) console.log(parts.join(' '));
  }
}).catch((e) => { console.error('BŁĄD:', e.message); process.exit(1); });
