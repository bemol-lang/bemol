const path = require('path'); const fs = require('fs');
const vscode = require('vscode');
const ext = require('../../extension.js');
ext.activate({ subscriptions: [] });
const file = path.resolve(process.argv[2]);
const lines = fs.readFileSync(file, 'utf8').split('\n');
const doc = { languageId: 'bemol', uri: { scheme: 'file', fsPath: file }, lineCount: lines.length,
  lineAt: (i) => ({ text: lines[i] }), getWordRangeAtPosition: (p) => new vscode.Range(p, p.translate(0, 3)) };
vscode._listeners.save(doc).then(() => {
  for (const d of vscode._diags.get(file) || []) console.log(d.code, `${d.range.start.line + 1}:${d.range.start.character + 1}`, d.message.split('\n')[0]);
});
