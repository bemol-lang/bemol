# BEMOL ♭ dla Visual Studio Code

Obsługa języka [BEMOL](https://github.com/bemol-lang/bemol) w VS Code (pliki `.bmol`).

## Co robi

- **kompilacja i uruchomienie:** `Ctrl+F5` (albo przycisk ▶ w prawym górnym rogu edytora) kompiluje bieżący plik i uruchamia program w terminalu VS Code, więc działa też `keyInput`. `Ctrl+Shift+B` tylko kompiluje. Polecenie **BEMOL: Finalbake i uruchom** jest w palecie poleceń (`Ctrl+Shift+P`),
- **sprawdzanie kodu przy zapisie:** błędy i ostrzeżenia kompilatora są podkreślane w edytorze (czerwona i żółta falka), z pełną treścią po najechaniu myszą (`[ ! ]`, `[ i ]`, `[ tip ]`) i w panelu **Problems** (`Ctrl+Shift+M`),

- **kolorowanie składni:** słowa struktury (`MAIN`, `FUNCTION`, `CONST`, `REF`...), sterowanie (`if`, `for`, `switch`...), zamknięcia `nazwa.end`, typy i soczewki (`.byte`, `.Color`, `.at`), metody bloków (`.new`, `.fill`, `.viewRectangle`...), literały `&FFh` / `&0101b` (niepoprawne, np. `&FF`, na czerwono), znaczniki `@ACCEPT` i `@ANYTHING_ELSE`, komentarze `#`,
- **automatyczne domykanie bloków:** Enter po `if ... then`, `for ... do`, `while ... do`, `foreach ... do`, `switch`, `repeat`, `MAIN BEGIN`, `FUNCTION nazwa(...)` wstawia pod kursorem `if.end`, `for.end`, `nazwa.end`, `MAIN END`, `until` itd. (tylko gdy zamknięcia jeszcze nie ma),
- **wcięcia:** automatyczne wcięcie w bloku i cofnięcie przy `.end`, `else`, `elseif`, `case`, `until`,
- **zwijanie bloków** strzałką obok numeru linii,
- **komentowanie** zaznaczenia skrótem `Ctrl+/`,
- **szablony** (wpisz i naciśnij Tab): `main`, `function`, `if`, `ifelse`, `ifelseif`, `for`, `forstep`, `foreach`, `foreachi`, `while`, `repeat`, `switch`, `pointer`, `struct`, `keyinput`, `println`.

## Wymagania

- **Python 3.8+** i **GCC** (jak dla prototypu tłumacza, zob. `prototyp/README.md`),
- **tłumacz `bemolc.py`**: rozszerzenie samo szuka go w folderze otwartego pliku i wyżej, także w podfolderze `prototyp/`. Można też wskazać ścieżkę w ustawieniach: **BEMOL › Compiler Path**.

Ustawienia (`Ctrl+,`, wpisz „bemol”): ścieżka do `bemolc.py`, polecenie Pythona (domyślnie `py -3` na Windows), włączenie i wyłączenie sprawdzania przy zapisie.

## Instalacja

1. W VS Code otwórz widok rozszerzeń (`Ctrl+Shift+X`).
2. Kliknij `...` w prawym górnym rogu widoku i wybierz **Install from VSIX...**.
3. Wskaż plik `bemol-0.2.0.vsix`.
4. Otwórz dowolny plik `.bmol`.
