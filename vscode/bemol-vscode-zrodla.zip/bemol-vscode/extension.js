// BEMOL ♭ dla VS Code:
//  1. automatyczne domykanie bloków (Enter po if ... then, for ... do, FUNCTION ... itd.),
//  2. podpięcie tłumacza bemolc.py: sprawdzanie kodu przy zapisie (błędy w edytorze i w panelu Problems),
//     kompilacja i uruchomienie programu w terminalu (Ctrl+F5).

const vscode = require('vscode');
const cp = require('child_process');
const fs = require('fs');
const path = require('path');

const OPENERS = [
  { re: /^(\s*)if\b.*\bthen\s*(#.*)?$/, closer: () => 'if.end' },
  { re: /^(\s*)for\b.*\bdo\s*(#.*)?$/, closer: () => 'for.end' },
  { re: /^(\s*)while\b.*\bdo\s*(#.*)?$/, closer: () => 'while.end' },
  { re: /^(\s*)foreach\b.*\bdo\s*(#.*)?$/, closer: () => 'foreach.end' },
  { re: /^(\s*)switch\b.*$/, closer: () => 'switch.end' },
  { re: /^(\s*)repeat\s*(#.*)?$/, closer: () => 'until ' },
  { re: /^(\s*)MAIN\s+BEGIN\s*(#.*)?$/, closer: () => 'MAIN END' },
  { re: /^(\s*)FUNCTION\s+(?:[A-Za-z_]\w*\.)?\.?([A-Za-z_]\w*)/, closer: (m) => `${m[2]}.end` },
  { re: /^(\s*)CLASS\s+([A-Za-z_]\w*)/, closer: (m) => `${m[2]}.end` },
];

function indentOf(text) {
  return text.match(/^\s*/)[0].length;
}

// Czy blok otwarty w linii `line` ma już zamknięcie (pierwsza linia na tym samym lub mniejszym wcięciu)?
function hasCloser(doc, line, indent, closer) {
  const word = closer.trim().split(/\s+/)[0];
  for (let i = line + 1; i < doc.lineCount; i++) {
    const t = doc.lineAt(i).text;
    if (t.trim() === '') continue;
    if (indentOf(t) < indent) return false;
    if (indentOf(t) === indent) {
      const first = t.trim();
      if (first.startsWith(word)) return true;
      if (/^(else|elseif|case)\b/.test(first)) continue;
      return false;
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// Tłumacz
// ---------------------------------------------------------------------------

let diagnostics;
let output;

function findCompiler(docPath) {
  const cfg = vscode.workspace.getConfiguration('bemol');
  const set = cfg.get('compilerPath');
  if (set) return set;
  // szukaj bemolc.py w folderze pliku i wyżej, także w podfolderze prototyp/
  let dir = path.dirname(docPath);
  for (let i = 0; i < 8; i++) {
    for (const cand of [path.join(dir, 'bemolc.py'), path.join(dir, 'prototyp', 'bemolc.py')]) {
      if (fs.existsSync(cand)) return cand;
    }
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  for (const f of vscode.workspace.workspaceFolders || []) {
    for (const cand of [path.join(f.uri.fsPath, 'bemolc.py'), path.join(f.uri.fsPath, 'prototyp', 'bemolc.py')]) {
      if (fs.existsSync(cand)) return cand;
    }
  }
  return null;
}

function pythonCommand() {
  const set = vscode.workspace.getConfiguration('bemol').get('pythonCommand');
  if (set) return { cmd: set, args: [] };
  return process.platform === 'win32' ? { cmd: 'py', args: ['-3'] } : { cmd: 'python3', args: [] };
}

// Uruchamia bemolc.py z formą komunikatów dla narzędzi; wynik: lista komunikatów i ewentualnie ścieżka programu.
function runCompiler(doc, extraArgs) {
  return new Promise((resolve) => {
    const compiler = findCompiler(doc.uri.fsPath);
    if (!compiler) {
      resolve({ fatal: 'Nie znaleziono tłumacza bemolc.py. Wskaż go w ustawieniu „bemol.compilerPath”.' });
      return;
    }
    const py = pythonCommand();
    const args = [...py.args, compiler, '-diagnostics=json', ...extraArgs, path.basename(doc.uri.fsPath)];
    cp.execFile(py.cmd, args, { cwd: path.dirname(doc.uri.fsPath), encoding: 'utf8', windowsHide: true },
      (err, stdout, stderr) => {
        if (err && err.code === 'ENOENT') {
          resolve({ fatal: `Nie znaleziono Pythona („${py.cmd}”). Zainstaluj go albo wskaż w ustawieniu „bemol.pythonCommand”.` });
          return;
        }
        const msgs = [];
        let exe = null;
        for (const line of stdout.split(/\r?\n/)) {
          if (!line.trim().startsWith('{')) continue;
          try {
            const j = JSON.parse(line);
            if (j.result === 'ok') exe = j.exe; else msgs.push(j);
          } catch (e) { /* pomiń */ }
        }
        if (stderr && stderr.trim()) output.appendLine(stderr.trim());
        resolve({ msgs, exe });
      });
  });
}

function showDiagnostics(doc, msgs) {
  const list = [];
  for (const m of msgs) {
    if (!m.file || path.basename(m.file) !== path.basename(doc.uri.fsPath)) continue;
    const line = Math.max(0, Math.min((m.line || 1) - 1, doc.lineCount - 1));
    const text = doc.lineAt(line).text;
    let range;
    if (m.column > 0) {
      const pos = new vscode.Position(line, Math.min(m.column - 1, text.length));
      range = doc.getWordRangeAtPosition(pos) || new vscode.Range(pos, pos.translate(0, 1));
    } else {
      const first = text.search(/\S/);
      range = new vscode.Range(line, Math.max(first, 0), line, text.length);
    }
    let message = m.message;
    if (m.detail) message += `\n[ i ] ${m.detail}`;
    if (m.help) message += `\n[ tip ] ${m.help}`;
    const d = new vscode.Diagnostic(range, message,
      m.severity === 'error' ? vscode.DiagnosticSeverity.Error : vscode.DiagnosticSeverity.Warning);
    d.code = m.code;
    d.source = 'BEMOL';
    list.push(d);
  }
  diagnostics.set(doc.uri, list);
}

async function check(doc) {
  if (doc.languageId !== 'bemol' || doc.uri.scheme !== 'file') return;
  if (!vscode.workspace.getConfiguration('bemol').get('checkOnSave')) return;
  const r = await runCompiler(doc, ['--check']);
  if (r.fatal) return;
  showDiagnostics(doc, r.msgs);
}

async function build(run, finalbake) {
  const editor = vscode.window.activeTextEditor;
  if (!editor || editor.document.languageId !== 'bemol') {
    vscode.window.showWarningMessage('Otwórz plik .bmol, który chcesz skompilować.');
    return;
  }
  const doc = editor.document;
  if (doc.isDirty) await doc.save();
  const r = await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Window, title: finalbake ? 'BEMOL: finalbake…' : 'BEMOL: kompilacja…' },
    () => runCompiler(doc, finalbake ? ['-finalbake'] : []));
  if (r.fatal) {
    vscode.window.showErrorMessage(r.fatal);
    return;
  }
  showDiagnostics(doc, r.msgs);
  const errors = r.msgs.filter((m) => m.severity === 'error');
  if (errors.length || !r.exe) {
    const other = errors.find((m) => !m.file);
    if (other) {
      vscode.window.showErrorMessage(`${other.code}: ${other.message}${other.help ? ' — ' + other.help.split('\n')[0] : ''}`);
    } else {
      vscode.window.showErrorMessage(`BEMOL: kompilacja nieudana (${errors.length} ${errors.length === 1 ? 'błąd' : 'błędy'}), szczegóły w panelu Problems.`);
      vscode.commands.executeCommand('workbench.actions.view.problems');
    }
    return;
  }
  if (!run) {
    vscode.window.setStatusBarMessage(`BEMOL: skompilowano ${path.basename(r.exe)}`, 5000);
    return;
  }
  const name = `BEMOL: ${path.basename(r.exe)}`;
  for (const t of vscode.window.terminals) if (t.name === name) t.dispose();
  const term = vscode.window.createTerminal({ name, shellPath: r.exe, cwd: path.dirname(r.exe) });
  term.show();
}

function activate(context) {
  diagnostics = vscode.languages.createDiagnosticCollection('bemol');
  output = vscode.window.createOutputChannel('BEMOL');
  context.subscriptions.push(diagnostics, output);
  context.subscriptions.push(
    vscode.commands.registerCommand('bemol.run', () => build(true, false)),
    vscode.commands.registerCommand('bemol.build', () => build(false, false)),
    vscode.commands.registerCommand('bemol.finalbake', () => build(true, true)),
    vscode.workspace.onDidSaveTextDocument(check),
    vscode.workspace.onDidOpenTextDocument(check),
    vscode.workspace.onDidCloseTextDocument((d) => diagnostics.delete(d.uri)),
  );
  for (const d of vscode.workspace.textDocuments) check(d);

  const sub = vscode.workspace.onDidChangeTextDocument((e) => {
    const editor = vscode.window.activeTextEditor;
    if (!editor || e.document !== editor.document || e.document.languageId !== 'bemol') return;
    if (e.contentChanges.length !== 1) return;
    const ch = e.contentChanges[0];
    if (!/^\r?\n[ \t]*$/.test(ch.text)) return;           // tylko zwykły Enter
    const openLine = ch.range.start.line;
    const text = e.document.lineAt(openLine).text;
    for (const o of OPENERS) {
      const m = text.match(o.re);
      if (!m) continue;
      const indentStr = m[1];
      const closer = o.closer(m);
      if (hasCloser(e.document, openLine + 1, indentStr.length, closer)) return;
      const eol = e.document.eol === vscode.EndOfLine.CRLF ? '\r\n' : '\n';
      const cursorLine = openLine + 1;
      const pos = e.document.lineAt(cursorLine).range.end;
      editor.edit(
        (b) => b.insert(pos, eol + indentStr + closer),
        { undoStopBefore: false, undoStopAfter: false }
      ).then(() => {
        const p = editor.document.lineAt(cursorLine).range.end;
        editor.selection = new vscode.Selection(p, p);
      });
      return;
    }
  });
  context.subscriptions.push(sub);
}

function deactivate() {}

module.exports = { activate, deactivate };
